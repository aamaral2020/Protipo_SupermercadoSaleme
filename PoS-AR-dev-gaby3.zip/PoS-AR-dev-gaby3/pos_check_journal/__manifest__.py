# -*- coding: utf-8 -*-
{
    'name': 'POS Check Journal',
    'version': '0.1',
    'author': 'Ing. Gabriela Rivero',
    'license': 'LGPL-3',
    'category': 'Point Of Sale',
    'website': 'www.galup.com.ar',
    'description': 'Este módulo chequea que los diarios de ventas y facturación sean los correctos.',
    'depends': ['point_of_sale'],
    'data': [
    ],
    'qweb': [
    ],
    'installable': True,
}
